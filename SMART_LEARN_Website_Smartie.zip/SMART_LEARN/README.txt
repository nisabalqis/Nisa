SMART LEARN — Prototaip Website Interaktif MBPK

CARA GUNA
1. Ekstrak fail ZIP.
2. Buka index.html menggunakan Google Chrome, Microsoft Edge atau pelayar moden.
3. Tekan butang Muzik Latar untuk menghidupkan/mematikan melodi.
4. Isi Profil Murid dengan nama samaran/kod murid.
5. Pilih permainan dan jawab lima soalan. Rekod disimpan secara automatik.

CIRI
- Antara muka berwarna-warni berdasarkan mockup SMART LEARN.
- Maskot robot Smartie dibina menggunakan SVG.
- Empat permainan kata nama, profil murid, prestasi, dashboard guru.
- Rekod skor, jawapan betul dan tempoh; graf trend; eksport CSV dan sandaran/import JSON.
- Muzik melodi ringkas melalui Web Audio API, tanpa fail audio luar.

NOTA PENTING
Data disimpan dalam localStorage pelayar/peranti sahaja, bukan pangkalan data awan dan tidak disegerakkan antara peranti. Gunakan kod samaran dan elakkan data pengenalan diri sensitif.
Skor permainan ialah petunjuk prestasi dalam tugasan khusus, bukan diagnosis atau ukuran menyeluruh perkembangan kognitif. Prototaip ini belum mengukur perkembangan motor halus secara sah; kemahiran motor perlu dinilai melalui aktiviti manipulatif dan pemerhatian guru. Untuk penggunaan sebenar di sekolah, perlukan backend, akaun, kawalan akses dan pengurusan data yang sesuai.
